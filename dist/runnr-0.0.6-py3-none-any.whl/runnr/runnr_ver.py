class runnr_ver:
    ver = 'v0.0.6'